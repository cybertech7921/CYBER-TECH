' CYBER TECH launcher - opens the software in its own app window
Option Explicit
Dim sh, fso, dir, app, url, cands, c, exe
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
app = dir & "\CyberTech.html"
If Not fso.FileExists(app) Then
  MsgBox "CyberTech.html was not found next to this launcher." & vbCrLf & "Keep all CYBER TECH files in the same folder.", 16, "CYBER TECH"
  WScript.Quit
End If
url = "file:///" & Replace(app, "\", "/")
cands = Array( _
  sh.ExpandEnvironmentStrings("%ProgramFiles(x86)%") & "\Microsoft\Edge\Application\msedge.exe", _
  sh.ExpandEnvironmentStrings("%ProgramFiles%") & "\Microsoft\Edge\Application\msedge.exe", _
  sh.ExpandEnvironmentStrings("%LocalAppData%") & "\Microsoft\Edge\Application\msedge.exe", _
  sh.ExpandEnvironmentStrings("%ProgramFiles%") & "\Google\Chrome\Application\chrome.exe", _
  sh.ExpandEnvironmentStrings("%ProgramFiles(x86)%") & "\Google\Chrome\Application\chrome.exe", _
  sh.ExpandEnvironmentStrings("%LocalAppData%") & "\Google\Chrome\Application\chrome.exe")
exe = ""
For Each c In cands
  If fso.FileExists(c) Then exe = c : Exit For
Next
If exe <> "" Then
  sh.Run """" & exe & """ --app=""" & url & """", 1, False
Else
  sh.Run "cmd /c start """" """ & app & """", 0, False
End If
