@echo off
rem Creates "CYBER TECH" shortcuts (with the logo icon) on the Desktop and in the Start menu.
set "CT_DIR=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; foreach($p in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){ $s=$w.CreateShortcut((Join-Path $p 'CYBER TECH.lnk')); $s.TargetPath=(Join-Path $env:CT_DIR 'CyberTech.vbs'); $s.WorkingDirectory=$env:CT_DIR; $s.IconLocation=(Join-Path $env:CT_DIR 'CyberTech.ico'); $s.Description='CYBER TECH - products and tax invoicing'; $s.Save() }"
echo.
echo CYBER TECH shortcut created on your Desktop and Start menu.
echo Keep this folder where it is - the shortcut opens the software from here.
echo.
pause
